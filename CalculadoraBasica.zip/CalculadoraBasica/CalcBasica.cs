﻿using System;
using System.Windows.Forms;

namespace CalcBasica
{
    public partial class CalcBasica : Form
    {
        public CalcBasica()
        {
            InitializeComponent();
        }

        private void CalcBasica_Load(object sender, EventArgs e)
        {
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            TxtResult.Clear();
        }

        private void Btn1_Click_1(object sender, EventArgs e)
        {
            TxtResult.Text += "1";
        }

        private void Btn2_Click(object sender, EventArgs e)
        {
            TxtResult.Text += "2";
        }
        private void Btn3_Click(object sender, EventArgs e)
        {
            TxtResult.Text += "3";
        }
        private void BtnSoma_Click(object sender, EventArgs e)
        {
            TxtResult.Text += "+";
        }

        private void BtnResult_Click(object sender, EventArgs e)
        {
            try
            {
                var parts = TxtResult.Text.Split('+');
                if (parts.Length == 2 &&
                    int.TryParse(parts[0], out int n1) &&
                    int.TryParse(parts[1], out int n2))
                {
                    TxtResult.Text = (n1 + n2).ToString();
                }
                else
                {
                    MessageBox.Show("Expressão inválida!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.Message);
            }
        }
    }
}
